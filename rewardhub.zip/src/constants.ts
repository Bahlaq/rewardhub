import { Offer } from './types';

export const MOCK_OFFERS: Offer[] = [];

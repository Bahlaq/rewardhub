# Assets for RewardHub
This folder contains the app icon and splash screen.
